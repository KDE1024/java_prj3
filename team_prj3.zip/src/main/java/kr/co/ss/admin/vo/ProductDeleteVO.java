package kr.co.ss.admin.vo;

public class ProductDeleteVO {
	private int prod_num;
	private String prod_delete;
	public int getProd_num() {
		return prod_num;
	}
	public void setProd_num(int prod_num) {
		this.prod_num = prod_num;
	}
	public String getProd_delete() {
		return prod_delete;
	}
	public void setProd_delete(String prod_delete) {
		this.prod_delete = prod_delete;
	}
	
	

}
