package kr.co.ss.admin.domain;

import java.util.List;

public class AdminLBImgListDomain {
	private String img;

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}


	

}
