package kr.co.ss.lookbook.vo;

public class InsertCommentVO {

	
	private int lb_posts_num;
	private String member_id, lb_comments;
	public int getLb_posts_num() {
		return lb_posts_num;
	}
	public void setLb_posts_num(int lb_posts_num) {
		this.lb_posts_num = lb_posts_num;
	}
	public String getMember_id() {
		return member_id;
	}
	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}

	public String getLb_comments() {
		return lb_comments;
	}
	public void setLb_comments(String lb_comments) {
		this.lb_comments = lb_comments;
	}
	
	
	
	
	
}//class
